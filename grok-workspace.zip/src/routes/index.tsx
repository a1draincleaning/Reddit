import { createFileRoute } from "@tanstack/react-router";
import { LaterApp } from "@/components/later-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <LaterApp />;
}
