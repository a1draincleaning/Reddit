/**
 * Later — the whole screen.
 * Data rules (storage key, statuses, duplicate matching, import) live in
 * src/lib/later.ts. This file is only the layout and the tap targets.
 * Links are never fetched or opened unless you tap Open.
 */
import { useEffect, useLayoutEffect, useMemo, useRef, useState, type FormEvent } from "react";
import {
  Check,
  ClipboardPaste,
  Copy,
  Download,
  ExternalLink,
  Pencil,
  Search,
  Shuffle,
  Trash2,
  Upload,
} from "lucide-react";
import {
  STORAGE_KEY,
  THEME_KEY,
  STATUS_META,
  counts,
  createItem,
  exportCsv,
  exportJson,
  extractUrl,
  findDuplicate,
  formatWhen,
  matchesDate,
  matchesQuery,
  matchesStatus,
  mergeItems,
  normalizeUrl,
  parseImport,
  parseStored,
  suggestName,
  domainOf,
  type DateFilter,
  type Item,
  type StatusFilter,
  type StatusId,
} from "@/lib/later";

type Theme = "dark" | "light";
type SortOrder = "newest" | "oldest";

const STATUS_FILTERS: { id: StatusFilter; label: string }[] = [
  { id: "all", label: "All" },
  { id: "to-check", label: "To check" },
  { id: "checked", label: "Checked" },
  { id: "keeper", label: "Keeper" },
  { id: "skip", label: "Skip" },
];

export function LaterApp() {
  const [ready, setReady] = useState(false);
  const [persist, setPersist] = useState(false);
  const [storageError, setStorageError] = useState<string | null>(null);
  const [items, setItems] = useState<Item[]>([]);
  const [theme, setTheme] = useState<Theme>("dark");

  const [url, setUrl] = useState("");
  const [name, setName] = useState("");
  const [note, setNote] = useState("");
  const [source, setSource] = useState("");
  const [nameDirty, setNameDirty] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [justSaved, setJustSaved] = useState<string | null>(null);

  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [dateFilter, setDateFilter] = useState<DateFilter>("all");
  const [sort, setSort] = useState<SortOrder>("newest");
  const [highlightId, setHighlightId] = useState<string | null>(null);

  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState({ name: "", url: "", note: "", source: "" });
  const [editError, setEditError] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [undo, setUndo] = useState<Item | null>(null);

  const [dataOpen, setDataOpen] = useState(false);
  const [replaceAll, setReplaceAll] = useState(false);
  const [importMessage, setImportMessage] = useState<string | null>(null);
  const [pending, setPending] = useState<Item[] | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const themeBooted = useRef(false);

  useLayoutEffect(() => {
    if (!themeBooted.current) {
      themeBooted.current = true;
      const stored: Theme = window.localStorage.getItem(THEME_KEY) === "light" ? "light" : "dark";
      setTheme(stored);
      document.documentElement.classList.toggle("dark", stored === "dark");
      paintThemeColor(stored);
      return;
    }
    document.documentElement.classList.toggle("dark", theme === "dark");
    paintThemeColor(theme);
  }, [theme]);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) setItems(parseStored(raw));
      setPersist(true);
    } catch (error) {
      setStorageError(error instanceof Error ? error.message : "Saved links could not be read.");
      setPersist(false);
    } finally {
      setReady(true);
    }
  }, []);

  useEffect(() => {
    if (!persist) return;
    window.localStorage.setItem(STORAGE_KEY, exportJson(items));
  }, [items, persist]);

  useEffect(() => {
    if (!import.meta.env.PROD) return;
    if (window.self !== window.top) return;
    if (!("serviceWorker" in navigator)) return;
    navigator.serviceWorker.register("/sw.js").catch(() => {});
  }, []);

  useEffect(() => {
    if (!highlightId) return;
    const node = document.getElementById(`link-${highlightId}`);
    if (!node) return;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    node.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "center" });
  }, [highlightId, items, statusFilter, dateFilter, query, sort]);

  const stats = useMemo(() => counts(items), [items]);
  const liveDuplicate = useMemo(() => (url.trim() ? findDuplicate(items, url) : undefined), [items, url]);
  const previewDomain = useMemo(() => {
    const normalized = normalizeUrl(url);
    return normalized ? domainOf(normalized) : "";
  }, [url]);

  const visible = useMemo(() => {
    const filtered = items.filter(
      (item) => matchesStatus(item, statusFilter) && matchesDate(item.savedAt, dateFilter) && matchesQuery(item, query),
    );
    filtered.sort((a, b) => (sort === "newest" ? b.savedAt.localeCompare(a.savedAt) : a.savedAt.localeCompare(b.savedAt)));
    return filtered;
  }, [items, statusFilter, dateFilter, query, sort]);

  function toggleTheme() {
    const next: Theme = theme === "dark" ? "light" : "dark";
    setTheme(next);
    window.localStorage.setItem(THEME_KEY, next);
  }

  function applyUrl(next: string, extracted = false) {
    const value = extracted ? extractUrl(next) : next;
    setUrl(value);
    setJustSaved(null);
    setFormError(null);
    if (!nameDirty) setName(suggestName(value));
  }

  async function pasteFromClipboard() {
    try {
      const text = await navigator.clipboard.readText();
      if (!text.trim()) {
        setFormError("Clipboard is empty.");
        return;
      }
      applyUrl(text, true);
    } catch {
      setFormError("Couldn’t read the clipboard. Long-press the link field and paste.");
    }
  }

  function saveLink() {
    if (!persist) return;
    let item: Item;
    try {
      item = createItem({ name, url, note, source });
    } catch {
      setFormError("That doesn’t look like a web link.");
      return;
    }
    setItems((current) => [item, ...current]);
    setUrl("");
    setName("");
    setNote("");
    setSource("");
    setNameDirty(false);
    setFormError(null);
    setJustSaved(item.name);
    setHighlightId(item.id);
    setUndo(null);
  }

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    // Enter never files a second copy. That takes the explicit button.
    if (findDuplicate(items, url)) return;
    saveLink();
  }

  function reveal(id: string) {
    setStatusFilter("all");
    setDateFilter("all");
    setQuery("");
    setHighlightId(id);
  }

  function pickRandom() {
    const pool = items.filter((item) => item.status === "to-check");
    if (pool.length === 0) return;
    const fresh = pool.filter((item) => item.id !== highlightId);
    const sourcePool = fresh.length > 0 ? fresh : pool;
    const choice = sourcePool[Math.floor(Math.random() * sourcePool.length)];
    reveal(choice.id);
  }

  function setStatus(id: string, status: StatusId) {
    setItems((current) => current.map((item) => (item.id === id ? { ...item, status } : item)));
  }

  function startEdit(item: Item) {
    setEditingId(item.id);
    setConfirmDeleteId(null);
    setEditError(null);
    setDraft({ name: item.name, url: item.url, note: item.note, source: item.source });
  }

  function saveEdit(item: Item) {
    let next: Item;
    try {
      next = createItem({
        id: item.id,
        name: draft.name,
        url: draft.url,
        note: draft.note,
        source: draft.source,
        status: item.status,
        savedAt: item.savedAt,
      });
    } catch {
      setEditError("That doesn’t look like a web link.");
      return;
    }
    if (findDuplicate(items, next.url, item.id)) {
      setEditError("You already have this link.");
      return;
    }
    setItems((current) => current.map((existing) => (existing.id === item.id ? next : existing)));
    setEditingId(null);
    setEditError(null);
  }

  function remove(item: Item) {
    setItems((current) => current.filter((existing) => existing.id !== item.id));
    setUndo(item);
    setConfirmDeleteId(null);
    if (editingId === item.id) setEditingId(null);
    if (highlightId === item.id) setHighlightId(null);
  }

  function restore() {
    if (!undo) return;
    setItems((current) => {
      if (findDuplicate(current, undo.url)) return current;
      return [undo, ...current];
    });
    setUndo(null);
  }

  async function copyUrl(value: string, id: string) {
    try {
      await navigator.clipboard.writeText(value);
      setCopiedId(id);
      window.setTimeout(() => setCopiedId((current) => (current === id ? null : current)), 1600);
    } catch {
      setFormError("Couldn’t copy that link.");
    }
  }

  function download(filename: string, content: string, type: string) {
    const blob = new Blob([content], { type });
    const objectUrl = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = objectUrl;
    anchor.download = filename;
    anchor.click();
    URL.revokeObjectURL(objectUrl);
  }

  function stamp() {
    const now = new Date();
    const month = String(now.getMonth() + 1).padStart(2, "0");
    const day = String(now.getDate()).padStart(2, "0");
    return `${now.getFullYear()}-${month}-${day}`;
  }

  async function onFile(file: File) {
    const text = await file.text();
    if (fileRef.current) fileRef.current.value = "";
    let incoming: Item[];
    try {
      incoming = parseImport(text);
    } catch (error) {
      setPending(null);
      setImportMessage(error instanceof Error ? error.message : "Couldn’t read that file.");
      return;
    }
    if (incoming.length === 0) {
      setPending(null);
      setImportMessage("No links found in that file.");
      return;
    }
    if (storageError && !replaceAll) {
      setPending(null);
      setImportMessage("Saved links couldn’t be read. Turn on “Replace the whole list” to import anyway.");
      return;
    }
    if (replaceAll) {
      setPending(incoming);
      setImportMessage(null);
      return;
    }
    const result = mergeItems(items, incoming);
    setItems(result.items);
    setPersist(true);
    setStorageError(null);
    setPending(null);
    setImportMessage(`Added ${result.added}. Skipped ${result.skipped} already saved.`);
  }

  function confirmReplace() {
    if (!pending) return;
    setItems(pending);
    setPersist(true);
    setStorageError(null);
    setImportMessage(`Replaced the list with ${pending.length} ${pending.length === 1 ? "link" : "links"}.`);
    setPending(null);
  }

  return (
    <main className="shell flex flex-col gap-5" data-ready={ready ? "true" : "false"}>
      <header className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h1 className="wordmark">Later</h1>
          <p className="mt-1 text-sm text-muted-foreground">Save a link. Decide later.</p>
        </div>
        <div className="flex shrink-0 gap-2">
          <button
            type="button"
            className="btn btn-secondary"
            aria-expanded={dataOpen}
            aria-controls="data-panel"
            onClick={() => setDataOpen((open) => !open)}
          >
            Data
          </button>
          <button
            type="button"
            className="btn btn-secondary"
            aria-label={theme === "dark" ? "Switch to light theme" : "Switch to dark theme"}
            onClick={toggleTheme}
          >
            {theme === "dark" ? "Light" : "Dark"}
          </button>
        </div>
      </header>

      {dataOpen ? (
        <section id="data-panel" className="panel flex flex-col gap-3" aria-label="Backup and install">
          <p className="text-sm text-muted-foreground">
            Everything stays in this browser. Export a file if you want a backup. Clearing site data deletes the list.
          </p>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => download(`later-${stamp()}.json`, exportJson(items), "application/json")}
            >
              <Download className="size-4" aria-hidden /> JSON
            </button>
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => download(`later-${stamp()}.csv`, exportCsv(items), "text/csv")}
            >
              <Download className="size-4" aria-hidden /> CSV
            </button>
          </div>
          <label className="flex min-h-11 items-center gap-3 text-sm">
            <input
              type="checkbox"
              checked={replaceAll}
              onChange={(event) => {
                setReplaceAll(event.target.checked);
                setPending(null);
              }}
            />
            Replace the whole list
          </label>
          <button type="button" className="btn btn-secondary btn-block" onClick={() => fileRef.current?.click()}>
            <Upload className="size-4" aria-hidden /> Import JSON or CSV
          </button>
          <input
            ref={fileRef}
            className="sr-only"
            type="file"
            accept=".json,.csv,application/json,text/csv"
            onChange={(event) => {
              const file = event.target.files?.[0];
              if (file) void onFile(file);
            }}
          />
          {pending ? (
            <div className="flex flex-col gap-2" role="alert">
              <p className="text-sm">
                Replace {items.length} saved {items.length === 1 ? "link" : "links"} with {pending.length} from the file?
              </p>
              <div className="grid grid-cols-2 gap-2">
                <button type="button" className="btn btn-danger" onClick={confirmReplace}>
                  Replace
                </button>
                <button type="button" className="btn btn-secondary" onClick={() => setPending(null)}>
                  Cancel
                </button>
              </div>
            </div>
          ) : null}
          {importMessage ? (
            <p className="text-sm text-muted-foreground" role="status">
              {importMessage}
            </p>
          ) : null}
          <div className="grid gap-2 text-sm text-muted-foreground">
            <p className="font-medium text-foreground">Add to your home screen</p>
            <p>Android: open the published app in Chrome, then the browser menu, then Install app or Add to Home screen.</p>
            <p>iPhone: open it in Safari, tap Share, then Add to Home Screen.</p>
            <p>After it has loaded once, the list still opens with no connection. Nothing is sent to a server.</p>
          </div>
        </section>
      ) : null}

      {storageError ? (
        <div className="panel flex flex-col gap-3" role="alert">
          <p className="text-sm">{storageError} New saves are paused so the old data is not overwritten.</p>
          <button
            type="button"
            className="btn btn-secondary"
            onClick={() => {
              setItems([]);
              setPersist(true);
              setStorageError(null);
            }}
          >
            Start fresh
          </button>
        </div>
      ) : null}

      <form className="panel flex flex-col gap-3" onSubmit={onSubmit}>
            <div className="grid gap-1.5">
              <label className="text-sm font-medium" htmlFor="link-url">
                Link
              </label>
              <div className="flex gap-2">
              <input
                id="link-url"
                className="field min-w-0"
                inputMode="url"
                autoCapitalize="off"
                autoCorrect="off"
                spellCheck={false}
                autoComplete="off"
                placeholder="https://"
                aria-invalid={formError ? true : undefined}
                value={url}
                onChange={(event) => applyUrl(event.target.value)}
                onPaste={(event) => {
                  const text = event.clipboardData.getData("text");
                  const next = extractUrl(text);
                  if (next && next !== text.trim()) {
                    event.preventDefault();
                    applyUrl(next, true);
                  }
                }}
              />
              <button type="button" className="btn btn-secondary shrink-0" onClick={() => void pasteFromClipboard()}>
                <ClipboardPaste className="size-4" aria-hidden /> Paste
              </button>
              </div>
            </div>
            {previewDomain ? <p className="text-sm text-subtle-foreground">{previewDomain}</p> : null}

            <label className="grid gap-1.5 text-sm font-medium" htmlFor="link-name">
              Name
              <input
                id="link-name"
                className="field"
                autoComplete="off"
                placeholder="Suggested from the link"
                value={name}
                onChange={(event) => {
                  setName(event.target.value);
                  setNameDirty(event.target.value.trim().length > 0);
                  setJustSaved(null);
                }}
              />
            </label>

            <details>
              <summary className="btn btn-secondary btn-block">Note and source</summary>
              <div className="mt-3 flex flex-col gap-3">
                <label className="grid gap-1.5 text-sm font-medium" htmlFor="link-note">
                  Note <span className="font-normal text-muted-foreground">optional</span>
                  <textarea
                    id="link-note"
                    className="field"
                    placeholder="Why it looked worth opening"
                    value={note}
                    onChange={(event) => {
                      setNote(event.target.value);
                      setJustSaved(null);
                    }}
                  />
                </label>
                <label className="grid gap-1.5 text-sm font-medium" htmlFor="link-source">
                  Source <span className="font-normal text-muted-foreground">optional</span>
                  <input
                    id="link-source"
                    className="field"
                    autoComplete="off"
                    spellCheck={false}
                    placeholder="r/androidapps or a post title"
                    value={source}
                    onChange={(event) => setSource(event.target.value)}
                  />
                </label>
              </div>
            </details>

            {liveDuplicate ? (
              <div className="rounded-sm border border-border bg-elevated px-3 py-3 text-sm" role="status">
                <p>
                  Already saved as <span className="font-medium text-foreground">{liveDuplicate.name}</span>
                  {` · ${formatWhen(liveDuplicate.savedAt)}`}.
                </p>
                <button type="button" className="btn btn-secondary mt-2" onClick={() => reveal(liveDuplicate.id)}>
                  Show saved link
                </button>
              </div>
            ) : null}

            {formError ? (
              <p className="text-sm text-skip" role="alert">
                {formError}
              </p>
            ) : null}
            {justSaved && !liveDuplicate ? (
              <p className="text-sm text-keep" role="status">
                Saved {justSaved}
              </p>
            ) : null}

            <button
              type={liveDuplicate ? "button" : "submit"}
              className="btn btn-primary btn-block"
              disabled={!persist || !url.trim()}
              onClick={liveDuplicate ? saveLink : undefined}
            >
              {liveDuplicate ? "Save another copy" : "Save link"}
            </button>
          </form>

          {!ready ? null : items.length > 0 ? (
            <section className="flex flex-col gap-3" aria-label="Saved links">
              <p className="text-sm text-muted-foreground">
                <span className="font-medium text-foreground tabular-nums">{stats.saved}</span> saved
                <span aria-hidden> · </span>
                <span className="font-medium text-foreground tabular-nums">{stats.checked}</span> checked
                <span aria-hidden> · </span>
                <span className="font-medium text-keep tabular-nums">{stats.kept}</span> kept
                <span aria-hidden> · </span>
                <span className="font-medium text-skip tabular-nums">{stats.skipped}</span> skipped
              </p>

              <div className="flex items-center gap-2">
                <Search className="size-4 shrink-0 text-muted-foreground" aria-hidden />
                <label className="sr-only" htmlFor="link-search">
                  Search saved links
                </label>
                <input
                  id="link-search"
                  className="field"
                  type="search"
                  placeholder="Search name, note, subreddit"
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                />
              </div>

              <div className="flex flex-wrap gap-2" role="group" aria-label="Filter by status">
                {STATUS_FILTERS.map((filter) => (
                  <button
                    key={filter.id}
                    type="button"
                    className="btn btn-secondary"
                    aria-pressed={statusFilter === filter.id}
                    onClick={() => setStatusFilter(filter.id)}
                  >
                    {filter.label}
                  </button>
                ))}
              </div>

              <div className="grid grid-cols-2 gap-2">
                <label className="sr-only" htmlFor="link-when">
                  Filter by date saved
                </label>
                <select
                  id="link-when"
                  className="field"
                  value={dateFilter}
                  onChange={(event) => setDateFilter(event.target.value as DateFilter)}
                >
                  <option value="all">Any date</option>
                  <option value="today">Today</option>
                  <option value="7d">Last 7 days</option>
                  <option value="30d">Last 30 days</option>
                </select>
                <label className="sr-only" htmlFor="link-sort">
                  Sort by date saved
                </label>
                <select
                  id="link-sort"
                  className="field"
                  value={sort}
                  onChange={(event) => setSort(event.target.value as SortOrder)}
                >
                  <option value="newest">Newest</option>
                  <option value="oldest">Oldest</option>
                </select>
              </div>

              <button type="button" className="btn btn-secondary btn-block" onClick={pickRandom} disabled={stats.open === 0}>
                <Shuffle className="size-4" aria-hidden />
                {stats.open === 0 ? "Nothing left to check" : "Pick one to check"}
              </button>

              {undo ? (
                <div className="panel flex items-center justify-between gap-3" role="status">
                  <p className="min-w-0 truncate text-sm">Removed {undo.name}</p>
                  <button type="button" className="btn btn-secondary shrink-0" onClick={restore}>
                    Undo
                  </button>
                </div>
              ) : null}

              {visible.length === 0 ? (
                <div className="panel flex flex-col gap-2">
                  <p className="text-sm text-muted-foreground">Nothing matches.</p>
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={() => {
                      setQuery("");
                      setStatusFilter("all");
                      setDateFilter("all");
                    }}
                  >
                    Clear filters
                  </button>
                </div>
              ) : (
                <ul className="flex flex-col gap-3">
                  {visible.map((item) => (
                    <li key={item.id}>
                      <LinkCard
                        item={item}
                        featured={item.id === highlightId}
                        editing={editingId === item.id}
                        draft={draft}
                        editError={editError}
                        confirmDelete={confirmDeleteId === item.id}
                        copied={copiedId === item.id}
                        onDraft={setDraft}
                        onStatus={(status) => setStatus(item.id, status)}
                        onEdit={() => startEdit(item)}
                        onCancelEdit={() => {
                          setEditingId(null);
                          setEditError(null);
                        }}
                        onSaveEdit={() => saveEdit(item)}
                        onAskDelete={() => {
                          setConfirmDeleteId(item.id);
                          setEditingId(null);
                        }}
                        onCancelDelete={() => setConfirmDeleteId(null)}
                        onDelete={() => remove(item)}
                        onCopy={() => void copyUrl(item.url, item.id)}
                      />
                    </li>
                  ))}
                </ul>
              )}
            </section>
          ) : (
            <section className="panel">
              <h2 className="font-medium">Nothing saved yet</h2>
              <p className="mt-1 text-sm text-muted-foreground">
                Paste a link from Reddit. It stays on this device until you export it.
              </p>
            </section>
          )}
    </main>
  );
}

function paintThemeColor(theme: Theme) {
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute("content", theme === "dark" ? "#0e0e10" : "#f4f3ef");
}

function LinkCard({
  item,
  featured,
  editing,
  draft,
  editError,
  confirmDelete,
  copied,
  onDraft,
  onStatus,
  onEdit,
  onCancelEdit,
  onSaveEdit,
  onAskDelete,
  onCancelDelete,
  onDelete,
  onCopy,
}: {
  item: Item;
  featured: boolean;
  editing: boolean;
  draft: { name: string; url: string; note: string; source: string };
  editError: string | null;
  confirmDelete: boolean;
  copied: boolean;
  onDraft: (draft: { name: string; url: string; note: string; source: string }) => void;
  onStatus: (status: StatusId) => void;
  onEdit: () => void;
  onCancelEdit: () => void;
  onSaveEdit: () => void;
  onAskDelete: () => void;
  onCancelDelete: () => void;
  onDelete: () => void;
  onCopy: () => void;
}) {
  const tone = item.status === "keeper" ? "tone-keeper" : item.status === "skip" ? "tone-skip" : "";
  return (
    <article id={`link-${item.id}`} className={featured ? "panel is-featured flex flex-col gap-3" : "panel flex flex-col gap-3"}>
      {editing ? (
        <form
          className="flex flex-col gap-3"
          onSubmit={(event) => {
            event.preventDefault();
            onSaveEdit();
          }}
        >
          <label className="grid gap-1.5 text-sm font-medium" htmlFor="edit-name">
            Name
            <input
              id="edit-name"
              className="field"
              value={draft.name}
              onChange={(event) => onDraft({ ...draft, name: event.target.value })}
            />
          </label>
          <label className="grid gap-1.5 text-sm font-medium" htmlFor="edit-url">
            Link
            <input
              id="edit-url"
              className="field"
              inputMode="url"
              autoCapitalize="off"
              autoCorrect="off"
              spellCheck={false}
              value={draft.url}
              onChange={(event) => onDraft({ ...draft, url: event.target.value })}
            />
          </label>
          <label className="grid gap-1.5 text-sm font-medium" htmlFor="edit-note">
            Note
            <textarea
              id="edit-note"
              className="field"
              value={draft.note}
              onChange={(event) => onDraft({ ...draft, note: event.target.value })}
            />
          </label>
          <label className="grid gap-1.5 text-sm font-medium" htmlFor="edit-source">
            Source
            <input
              id="edit-source"
              className="field"
              value={draft.source}
              onChange={(event) => onDraft({ ...draft, source: event.target.value })}
            />
          </label>
          {editError ? (
            <p className="text-sm text-skip" role="alert">
              {editError}
            </p>
          ) : null}
          <div className="grid grid-cols-2 gap-2">
            <button type="submit" className="btn btn-primary">
              Save changes
            </button>
            <button type="button" className="btn btn-secondary" onClick={onCancelEdit}>
              Cancel
            </button>
          </div>
        </form>
      ) : (
        <>
          <div className="flex items-baseline justify-between gap-3">
            <h2 className="min-w-0 text-base font-semibold leading-snug">{item.name}</h2>
            <span className="max-w-32 shrink-0 truncate text-sm text-muted-foreground">{item.domain}</span>
          </div>
          {item.note ? <p className="text-sm break-words text-muted-foreground">{item.note}</p> : null}
          <p className={`text-sm ${tone || "text-muted-foreground"}`}>
            {statusLabel(item.status)}
            <span aria-hidden> · </span>
            {item.source ? `${item.source} · ` : ""}
            {formatWhen(item.savedAt)}
          </p>
          <p className="line-clamp-2 text-sm break-all text-subtle-foreground">{item.url}</p>
          <div className="grid grid-cols-3 gap-2" role="group" aria-label={`Status for ${item.name}`}>
            {STATUS_META.map((status) => (
              <button
                key={status.id}
                type="button"
                className="btn btn-secondary status-btn px-2 text-center"
                data-status={status.id}
                aria-pressed={item.status === status.id}
                aria-label={`Set ${item.name} to ${status.long}`}
                onClick={() => onStatus(status.id)}
              >
                {status.short}
              </button>
            ))}
          </div>
          {confirmDelete ? (
            <div className="grid grid-cols-2 gap-2" role="group" aria-label="Confirm delete">
              <button type="button" className="btn btn-danger" onClick={onDelete}>
                Delete
              </button>
              <button type="button" className="btn btn-secondary" onClick={onCancelDelete}>
                Cancel
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2">
              <a className="btn btn-secondary" href={item.url} target="_blank" rel="noopener noreferrer">
                <ExternalLink className="size-4" aria-hidden /> Open
              </a>
              <button type="button" className="btn btn-secondary" onClick={onCopy}>
                {copied ? <Check className="size-4" aria-hidden /> : <Copy className="size-4" aria-hidden />}
                {copied ? "Copied" : "Copy"}
              </button>
              <button type="button" className="btn btn-secondary" onClick={onEdit}>
                <Pencil className="size-4" aria-hidden /> Edit
              </button>
              <button type="button" className="btn btn-danger" onClick={onAskDelete}>
                <Trash2 className="size-4" aria-hidden /> Delete
              </button>
            </div>
          )}
        </>
      )}
    </article>
  );
}

function statusLabel(id: StatusId): string {
  return STATUS_META.find((status) => status.id === id)?.long ?? "To check";
}
