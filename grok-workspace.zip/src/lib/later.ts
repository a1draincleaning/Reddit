/**
 * Later — a link queue that never leaves this browser.
 *
 * Storage key: localStorage["later.links.v1"]
 * Shape: { v: 1, items: Item[] }
 *
 * Status ids stay stable so old saves still match. Change the labels here:
 *   to-check  "To check"
 *   keeper    "Checked – keeper"
 *   skip      "Checked – skip"
 *
 * Two URLs count as the same when the host (ignoring www), path, query, and
 * hash match after http/https is folded together, a trailing slash is dropped,
 * and common tracking params (utm_*, fbclid, gclid, …) are removed.
 * The path keeps its original casing. Nothing is fetched from the URL.
 */

export const STORAGE_KEY = "later.links.v1";
export const THEME_KEY = "later.theme";

export type StatusId = "to-check" | "keeper" | "skip";

export type Item = {
  id: string;
  name: string;
  url: string;
  domain: string;
  note: string;
  source: string;
  status: StatusId;
  savedAt: string;
};

export type DateFilter = "all" | "today" | "7d" | "30d";
export type StatusFilter = "all" | "to-check" | "checked" | "keeper" | "skip";

export const STATUS_META: { id: StatusId; short: string; long: string }[] = [
  { id: "to-check", short: "To check", long: "To check" },
  { id: "keeper", short: "Keeper", long: "Checked – keeper" },
  { id: "skip", short: "Skip", long: "Checked – skip" },
];

const TRACKING = new Set([
  "utm_source",
  "utm_medium",
  "utm_campaign",
  "utm_term",
  "utm_content",
  "utm_id",
  "utm_name",
  "fbclid",
  "gclid",
  "gbraid",
  "wbraid",
  "igshid",
  "mc_cid",
  "mc_eid",
  "ref",
  "ref_src",
  "si",
]);

const PUBLIC_SUFFIX_2 = new Set([
  "co.uk",
  "org.uk",
  "ac.uk",
  "com.au",
  "net.au",
  "co.nz",
  "co.jp",
  "com.br",
  "com.mx",
  "co.za",
  "com.tr",
]);

const HOSTERS = new Set([
  "github.io",
  "vercel.app",
  "netlify.app",
  "pages.dev",
  "web.app",
  "firebaseapp.com",
  "herokuapp.com",
  "glitch.me",
  "notion.site",
  "framer.app",
  "fly.dev",
]);

export function statusMeta(id: StatusId) {
  return STATUS_META.find((status) => status.id === id) ?? STATUS_META[0];
}

/** Pull a URL out of a Reddit share, a markdown link, or a bare paste. */
export function extractUrl(text: string): string {
  const markdown = text.match(/\((https?:\/\/[^)\s]+)\)/i);
  if (markdown?.[1]) return trimUrlJunk(markdown[1]);
  const absolute = text.match(/https?:\/\/[^\s<>"']+/i);
  if (absolute?.[0]) return trimUrlJunk(absolute[0]);
  return text.trim();
}

function trimUrlJunk(value: string): string {
  return value.replace(/[),.;]+$/, "");
}

/**
 * Canonical URL we store and compare.
 * Returns null when the text is not an http(s) link.
 */
export function normalizeUrl(raw: string): string | null {
  const extracted = extractUrl(raw);
  if (!extracted) return null;
  let candidate = extracted;
  if (!/^[a-z][a-z0-9+.-]*:/i.test(candidate)) candidate = `https://${candidate}`;
  let url: URL;
  try {
    url = new URL(candidate);
  } catch {
    return null;
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") return null;
  if (url.protocol === "http:" && (url.port === "" || url.port === "80")) {
    url.protocol = "https:";
    url.port = "";
  }
  url.hostname = url.hostname.toLowerCase().replace(/^www\./, "");
  if (url.protocol === "https:" && url.port === "443") url.port = "";
  const kept = [...url.searchParams.entries()]
    .filter(([key]) => !TRACKING.has(key.toLowerCase()))
    .sort((a, b) => a[0].localeCompare(b[0]) || a[1].localeCompare(b[1]));
  url.search = "";
  for (const [key, value] of kept) url.searchParams.append(key, value);
  if (url.pathname.length > 1 && url.pathname.endsWith("/")) {
    url.pathname = url.pathname.slice(0, -1);
  }
  return url.toString();
}

export function domainOf(normalized: string): string {
  try {
    return new URL(normalized).hostname;
  } catch {
    return "";
  }
}

export function suggestName(raw: string): string {
  const normalized = normalizeUrl(raw);
  if (!normalized) return "";
  const url = new URL(normalized);
  const host = url.hostname;
  if (host === "youtu.be" || host.endsWith("youtube.com")) return "YouTube";
  if (host === "apps.apple.com" || host.endsWith(".apple.com")) {
    const parts = url.pathname.split("/").filter(Boolean);
    const appAt = parts.indexOf("app");
    if (appAt >= 0 && parts[appAt + 1] && !parts[appAt + 1].startsWith("id")) {
      return titleCase(parts[appAt + 1]);
    }
  }
  if (host === "play.google.com") {
    const id = url.searchParams.get("id");
    if (id) return titleCase(id.split(".").pop() ?? id);
  }
  if (host === "github.com" || host.endsWith(".github.com")) {
    const parts = url.pathname.split("/").filter(Boolean);
    if (parts[1]) return titleCase(parts[1]);
    if (parts[0]) return titleCase(parts[0]);
  }
  if (host.endsWith("reddit.com")) {
    const parts = url.pathname.split("/").filter(Boolean);
    if (parts[0] === "r" && parts[1]) return `r/${parts[1]}`;
  }
  return titleCase(siteLabel(host));
}

function siteLabel(hostname: string): string {
  const parts = hostname.split(".").filter(Boolean);
  if (parts.length <= 1) return parts[0] ?? hostname;
  const last2 = parts.slice(-2).join(".");
  const last3 = parts.slice(-3).join(".");
  if (HOSTERS.has(last2) && parts.length >= 3) return parts[parts.length - 3];
  if (HOSTERS.has(last3) && parts.length >= 4) return parts[parts.length - 4];
  if (PUBLIC_SUFFIX_2.has(last2) && parts.length >= 3) return parts[parts.length - 3];
  return parts[parts.length - 2];
}

function titleCase(value: string): string {
  let cleaned = value;
  try {
    cleaned = decodeURIComponent(value);
  } catch {
    cleaned = value;
  }
  cleaned = cleaned.replace(/[-_]+/g, " ").replace(/\s+/g, " ").trim();
  if (!cleaned) return "";
  return cleaned.replace(/(^|\s)([a-z])/g, (_match, space: string, char: string) => space + char.toUpperCase());
}

export function findDuplicate(items: Item[], rawUrl: string, exceptId?: string): Item | undefined {
  const key = normalizeUrl(rawUrl);
  if (!key) return undefined;
  return items.find((item) => item.id !== exceptId && normalizeUrl(item.url) === key);
}

export function counts(items: Item[]) {
  let kept = 0;
  let skipped = 0;
  for (const item of items) {
    if (item.status === "keeper") kept += 1;
    else if (item.status === "skip") skipped += 1;
  }
  return {
    saved: items.length,
    checked: kept + skipped,
    kept,
    skipped,
    open: items.length - kept - skipped,
  };
}

export function matchesDate(iso: string, filter: DateFilter, now = new Date()): boolean {
  if (filter === "all") return true;
  const time = new Date(iso).getTime();
  if (Number.isNaN(time)) return false;
  if (filter === "today") {
    const start = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    return time >= start && time < start + 86_400_000;
  }
  const days = filter === "7d" ? 7 : 30;
  return time >= now.getTime() - days * 86_400_000;
}

export function matchesQuery(item: Item, query: string): boolean {
  const needle = query.trim().toLowerCase();
  if (!needle) return true;
  const haystack = [item.name, item.url, item.domain, item.note, item.source, statusMeta(item.status).long, statusMeta(item.status).short]
    .join("\n")
    .toLowerCase();
  return haystack.includes(needle);
}

export function matchesStatus(item: Item, filter: StatusFilter): boolean {
  if (filter === "all") return true;
  if (filter === "checked") return item.status === "keeper" || item.status === "skip";
  return item.status === filter;
}

export function formatWhen(iso: string, now = new Date()): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "";
  const startToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const startThat = new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
  const diff = Math.round((startToday - startThat) / 86_400_000);
  if (diff === 0) return "Today";
  if (diff === 1) return "Yesterday";
  return date.toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    year: date.getFullYear() === now.getFullYear() ? undefined : "numeric",
  });
}

export function createItem(input: {
  name: string;
  url: string;
  note?: string;
  source?: string;
  status?: StatusId;
  savedAt?: string;
  id?: string;
}): Item {
  const url = normalizeUrl(input.url);
  if (!url) throw new Error("Not a web link");
  const name = input.name.trim() || suggestName(url) || domainOf(url);
  return {
    id: input.id?.trim() || newId(),
    name,
    url,
    domain: domainOf(url),
    note: (input.note ?? "").trim(),
    source: (input.source ?? "").trim(),
    status: input.status ?? "to-check",
    savedAt: input.savedAt && !Number.isNaN(new Date(input.savedAt).getTime()) ? new Date(input.savedAt).toISOString() : new Date().toISOString(),
  };
}

export function exportJson(items: Item[]): string {
  return JSON.stringify({ v: 1, items }, null, 2);
}

const CSV_COLUMNS = ["name", "url", "domain", "note", "source", "status", "savedAt"] as const;

export function exportCsv(items: Item[]): string {
  const lines = [CSV_COLUMNS.join(",")];
  for (const item of items) {
    lines.push(CSV_COLUMNS.map((column) => csvEscape(item[column])).join(","));
  }
  return lines.join("\n");
}

function csvEscape(value: string): string {
  if (/[",\n\r]/.test(value)) return `"${value.replace(/"/g, '""')}"`;
  return value;
}

export function parseCsvRows(text: string): string[][] {
  const source = text.replace(/^\uFEFF/, "");
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = "";
  let quoted = false;
  for (let i = 0; i < source.length; i += 1) {
    const char = source[i];
    if (quoted) {
      if (char === '"') {
        if (source[i + 1] === '"') {
          cell += '"';
          i += 1;
        } else {
          quoted = false;
        }
      } else {
        cell += char;
      }
      continue;
    }
    if (char === '"') {
      quoted = true;
      continue;
    }
    if (char === ",") {
      row.push(cell);
      cell = "";
      continue;
    }
    if (char === "\n") {
      row.push(cell);
      rows.push(row);
      row = [];
      cell = "";
      continue;
    }
    if (char === "\r") continue;
    cell += char;
  }
  if (cell.length > 0 || row.length > 0) {
    row.push(cell);
    rows.push(row);
  }
  return rows;
}

export function parseStored(raw: string): Item[] {
  let data: unknown;
  try {
    data = JSON.parse(raw);
  } catch {
    throw new Error("Saved links could not be read.");
  }
  const list = Array.isArray(data) ? data : isRecord(data) ? data.items : null;
  if (!Array.isArray(list)) throw new Error("Saved links could not be read.");
  const items = list.map(coerceItem).filter((item): item is Item => item !== null);
  if (list.length > 0 && items.length === 0) throw new Error("Saved links could not be read.");
  return sortNewest(dedupeIds(items));
}

/** Import either the JSON export or a CSV with a url column. */
export function parseImport(text: string): Item[] {
  const trimmed = text.replace(/^\uFEFF/, "").trim();
  if (!trimmed) return [];
  if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
    const items = parseStored(trimmed);
    return items;
  }
  return parseCsv(trimmed);
}

export function parseCsv(text: string): Item[] {
  const rows = parseCsvRows(text).filter((row) => row.some((cell) => cell.trim()));
  if (rows.length === 0) return [];
  const header = rows[0].map((cell) => cell.trim().toLowerCase().replace(/[\s_-]/g, ""));
  const urlIndex = header.indexOf("url");
  if (urlIndex === -1) throw new Error("CSV needs a url column.");
  const indexOf = (name: string) => header.indexOf(name);
  const savedIndex = indexOf("savedat") === -1 ? indexOf("date") : indexOf("savedat");
  const items: Item[] = [];
  for (const row of rows.slice(1)) {
    const rawUrl = row[urlIndex] ?? "";
    if (!normalizeUrl(rawUrl)) continue;
    const pick = (name: string) => {
      const index = indexOf(name);
      return index === -1 ? "" : (row[index] ?? "");
    };
    const item = coerceItem({
      id: pick("id"),
      name: pick("name"),
      url: rawUrl,
      note: pick("note"),
      source: pick("source"),
      status: pick("status"),
      savedAt: savedIndex === -1 ? "" : (row[savedIndex] ?? ""),
    });
    if (item) items.push(item);
  }
  return sortNewest(dedupeIds(items));
}

export function mergeItems(current: Item[], incoming: Item[]): { items: Item[]; added: number; skipped: number } {
  const seen = new Set(current.map((item) => normalizeUrl(item.url)).filter((url): url is string => Boolean(url)));
  const next = [...current];
  let added = 0;
  let skipped = 0;
  for (const item of incoming) {
    const key = normalizeUrl(item.url);
    if (!key || seen.has(key)) {
      skipped += 1;
      continue;
    }
    seen.add(key);
    next.push({ ...item, url: key, domain: domainOf(key) });
    added += 1;
  }
  return { items: sortNewest(dedupeIds(next)), added, skipped };
}

function coerceItem(value: unknown): Item | null {
  const record = isRecord(value) ? value : null;
  if (!record) return null;
  const rawUrl = typeof record.url === "string" ? record.url : "";
  const url = normalizeUrl(rawUrl);
  if (!url) return null;
  const nameValue = typeof record.name === "string" ? record.name.trim() : "";
  const savedRaw = typeof record.savedAt === "string" ? record.savedAt : "";
  const savedAt = savedRaw && !Number.isNaN(new Date(savedRaw).getTime()) ? new Date(savedRaw).toISOString() : new Date().toISOString();
  return {
    id: typeof record.id === "string" && record.id.trim() ? record.id.trim() : newId(),
    name: nameValue || suggestName(url) || domainOf(url),
    url,
    domain: domainOf(url),
    note: typeof record.note === "string" ? record.note.trim() : "",
    source: typeof record.source === "string" ? record.source.trim() : "",
    status: coerceStatus(record.status),
    savedAt,
  };
}

function coerceStatus(value: unknown): StatusId {
  const text = String(value ?? "")
    .toLowerCase()
    .replace(/[–—]/g, "-")
    .replace(/\s+/g, " ")
    .trim();
  if (["keeper", "kept", "keep", "checked - keeper", "checked-keeper"].includes(text)) return "keeper";
  if (["skip", "skipped", "checked - skip", "checked-skip"].includes(text)) return "skip";
  return "to-check";
}

function dedupeIds(items: Item[]): Item[] {
  const seen = new Set<string>();
  return items.map((item) => {
    if (!seen.has(item.id)) {
      seen.add(item.id);
      return item;
    }
    const id = newId();
    seen.add(id);
    return { ...item, id };
  });
}

function sortNewest(items: Item[]): Item[] {
  return [...items].sort((a, b) => b.savedAt.localeCompare(a.savedAt) || a.name.localeCompare(b.name));
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function newId(): string {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return crypto.randomUUID();
  return `id-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}
