import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  exportCsv,
  extractUrl,
  findDuplicate,
  mergeItems,
  normalizeUrl,
  parseCsv,
  parseImport,
  parseStored,
  suggestName,
  type Item,
} from "./later.ts";

describe("normalizeUrl", () => {
  it("folds scheme, www, tracking params, and a trailing slash", () => {
    const a = normalizeUrl("http://www.Example.com/app/?utm_source=reddit&id=1");
    const b = normalizeUrl("https://example.com/app/?id=1");
    assert.equal(a, b);
    assert.equal(a, "https://example.com/app?id=1");
  });

  it("rejects non-web links", () => {
    assert.equal(normalizeUrl("javascript:alert(1)"), null);
    assert.equal(normalizeUrl(""), null);
  });

  it("keeps a hash so two sections stay distinct", () => {
    assert.notEqual(normalizeUrl("https://example.com/docs#install"), normalizeUrl("https://example.com/docs#usage"));
  });
});

describe("suggestName", () => {
  it("reads a product name from common app links", () => {
    assert.equal(suggestName("https://apps.apple.com/us/app/things-3/id904237743"), "Things 3");
    assert.equal(suggestName("https://github.com/someone/cool-tool"), "Cool Tool");
    assert.equal(suggestName("raycast.com"), "Raycast");
    assert.equal(suggestName("https://www.reddit.com/r/androidapps/comments/abc/title"), "r/androidapps");
  });
});

describe("extractUrl", () => {
  it("pulls a link out of a reddit-style paste", () => {
    assert.equal(extractUrl("Check this (https://example.com/a), worth it."), "https://example.com/a");
  });
});

describe("import and duplicates", () => {
  const sample: Item = {
    id: "1",
    name: "Raycast",
    url: "https://raycast.com",
    domain: "raycast.com",
    note: 'says "fast"',
    source: "r/macapps",
    status: "keeper",
    savedAt: "2026-11-01T12:00:00.000Z",
  };

  it("round-trips csv including commas and quotes", () => {
    const csv = exportCsv([sample]);
    const parsed = parseCsv(csv);
    assert.equal(parsed.length, 1);
    assert.equal(parsed[0].name, "Raycast");
    assert.equal(parsed[0].note, 'says "fast"');
    assert.equal(parsed[0].status, "keeper");
    assert.equal(parsed[0].source, "r/macapps");
  });

  it("reads the json export and merges without a second copy", () => {
    const raw = JSON.stringify({ v: 1, items: [sample] });
    const imported = parseImport(raw);
    assert.equal(parseStored(raw)[0].url, "https://raycast.com/");
    const merged = mergeItems([sample], imported);
    assert.equal(merged.added, 0);
    assert.equal(merged.skipped, 1);
    assert.ok(findDuplicate([sample], "https://www.raycast.com/?utm_source=reddit"));
  });
});
