import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Search, c as Download, d as Check, i as Shuffle, l as Copy, o as Pencil, r as Trash2, s as ExternalLink, t as Upload, u as ClipboardPaste } from "../_libs/lucide-react.mjs";
import { _ as normalizeUrl, a as counts, b as suggestName, c as exportCsv, d as findDuplicate, f as formatWhen, g as mergeItems, h as matchesStatus, i as THEME_KEY, l as exportJson, m as matchesQuery, n as STATUS_META, o as createItem, p as matchesDate, r as STORAGE_KEY, s as domainOf, u as extractUrl, v as parseImport, y as parseStored } from "./router-JWuuIuwH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-n6H6kIyr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Later — the whole screen.
* Data rules (storage key, statuses, duplicate matching, import) live in
* src/lib/later.ts. This file is only the layout and the tap targets.
* Links are never fetched or opened unless you tap Open.
*/
var STATUS_FILTERS = [
	{
		id: "all",
		label: "All"
	},
	{
		id: "to-check",
		label: "To check"
	},
	{
		id: "checked",
		label: "Checked"
	},
	{
		id: "keeper",
		label: "Keeper"
	},
	{
		id: "skip",
		label: "Skip"
	}
];
function LaterApp() {
	const [ready, setReady] = (0, import_react.useState)(false);
	const [persist, setPersist] = (0, import_react.useState)(false);
	const [storageError, setStorageError] = (0, import_react.useState)(null);
	const [items, setItems] = (0, import_react.useState)([]);
	const [theme, setTheme] = (0, import_react.useState)("dark");
	const [url, setUrl] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [source, setSource] = (0, import_react.useState)("");
	const [nameDirty, setNameDirty] = (0, import_react.useState)(false);
	const [formError, setFormError] = (0, import_react.useState)(null);
	const [justSaved, setJustSaved] = (0, import_react.useState)(null);
	const [query, setQuery] = (0, import_react.useState)("");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("all");
	const [dateFilter, setDateFilter] = (0, import_react.useState)("all");
	const [sort, setSort] = (0, import_react.useState)("newest");
	const [highlightId, setHighlightId] = (0, import_react.useState)(null);
	const [editingId, setEditingId] = (0, import_react.useState)(null);
	const [draft, setDraft] = (0, import_react.useState)({
		name: "",
		url: "",
		note: "",
		source: ""
	});
	const [editError, setEditError] = (0, import_react.useState)(null);
	const [confirmDeleteId, setConfirmDeleteId] = (0, import_react.useState)(null);
	const [copiedId, setCopiedId] = (0, import_react.useState)(null);
	const [undo, setUndo] = (0, import_react.useState)(null);
	const [dataOpen, setDataOpen] = (0, import_react.useState)(false);
	const [replaceAll, setReplaceAll] = (0, import_react.useState)(false);
	const [importMessage, setImportMessage] = (0, import_react.useState)(null);
	const [pending, setPending] = (0, import_react.useState)(null);
	const fileRef = (0, import_react.useRef)(null);
	const themeBooted = (0, import_react.useRef)(false);
	(0, import_react.useLayoutEffect)(() => {
		if (!themeBooted.current) {
			themeBooted.current = true;
			const stored = window.localStorage.getItem("later.theme") === "light" ? "light" : "dark";
			setTheme(stored);
			document.documentElement.classList.toggle("dark", stored === "dark");
			paintThemeColor(stored);
			return;
		}
		document.documentElement.classList.toggle("dark", theme === "dark");
		paintThemeColor(theme);
	}, [theme]);
	(0, import_react.useEffect)(() => {
		try {
			const raw = window.localStorage.getItem(STORAGE_KEY);
			if (raw) setItems(parseStored(raw));
			setPersist(true);
		} catch (error) {
			setStorageError(error instanceof Error ? error.message : "Saved links could not be read.");
			setPersist(false);
		} finally {
			setReady(true);
		}
	}, []);
	(0, import_react.useEffect)(() => {
		if (!persist) return;
		window.localStorage.setItem(STORAGE_KEY, exportJson(items));
	}, [items, persist]);
	(0, import_react.useEffect)(() => {
		if (window.self !== window.top) return;
		if (!("serviceWorker" in navigator)) return;
		navigator.serviceWorker.register("/sw.js").catch(() => {});
	}, []);
	(0, import_react.useEffect)(() => {
		if (!highlightId) return;
		const node = document.getElementById(`link-${highlightId}`);
		if (!node) return;
		const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		node.scrollIntoView({
			behavior: reduce ? "auto" : "smooth",
			block: "center"
		});
	}, [
		highlightId,
		items,
		statusFilter,
		dateFilter,
		query,
		sort
	]);
	const stats = (0, import_react.useMemo)(() => counts(items), [items]);
	const liveDuplicate = (0, import_react.useMemo)(() => url.trim() ? findDuplicate(items, url) : void 0, [items, url]);
	const previewDomain = (0, import_react.useMemo)(() => {
		const normalized = normalizeUrl(url);
		return normalized ? domainOf(normalized) : "";
	}, [url]);
	const visible = (0, import_react.useMemo)(() => {
		const filtered = items.filter((item) => matchesStatus(item, statusFilter) && matchesDate(item.savedAt, dateFilter) && matchesQuery(item, query));
		filtered.sort((a, b) => sort === "newest" ? b.savedAt.localeCompare(a.savedAt) : a.savedAt.localeCompare(b.savedAt));
		return filtered;
	}, [
		items,
		statusFilter,
		dateFilter,
		query,
		sort
	]);
	function toggleTheme() {
		const next = theme === "dark" ? "light" : "dark";
		setTheme(next);
		window.localStorage.setItem(THEME_KEY, next);
	}
	function applyUrl(next, extracted = false) {
		const value = extracted ? extractUrl(next) : next;
		setUrl(value);
		setJustSaved(null);
		setFormError(null);
		if (!nameDirty) setName(suggestName(value));
	}
	async function pasteFromClipboard() {
		try {
			const text = await navigator.clipboard.readText();
			if (!text.trim()) {
				setFormError("Clipboard is empty.");
				return;
			}
			applyUrl(text, true);
		} catch {
			setFormError("Couldn’t read the clipboard. Long-press the link field and paste.");
		}
	}
	function saveLink() {
		if (!persist) return;
		let item;
		try {
			item = createItem({
				name,
				url,
				note,
				source
			});
		} catch {
			setFormError("That doesn’t look like a web link.");
			return;
		}
		setItems((current) => [item, ...current]);
		setUrl("");
		setName("");
		setNote("");
		setSource("");
		setNameDirty(false);
		setFormError(null);
		setJustSaved(item.name);
		setHighlightId(item.id);
		setUndo(null);
	}
	function onSubmit(event) {
		event.preventDefault();
		if (findDuplicate(items, url)) return;
		saveLink();
	}
	function reveal(id) {
		setStatusFilter("all");
		setDateFilter("all");
		setQuery("");
		setHighlightId(id);
	}
	function pickRandom() {
		const pool = items.filter((item) => item.status === "to-check");
		if (pool.length === 0) return;
		const fresh = pool.filter((item) => item.id !== highlightId);
		const sourcePool = fresh.length > 0 ? fresh : pool;
		const choice = sourcePool[Math.floor(Math.random() * sourcePool.length)];
		reveal(choice.id);
	}
	function setStatus(id, status) {
		setItems((current) => current.map((item) => item.id === id ? {
			...item,
			status
		} : item));
	}
	function startEdit(item) {
		setEditingId(item.id);
		setConfirmDeleteId(null);
		setEditError(null);
		setDraft({
			name: item.name,
			url: item.url,
			note: item.note,
			source: item.source
		});
	}
	function saveEdit(item) {
		let next;
		try {
			next = createItem({
				id: item.id,
				name: draft.name,
				url: draft.url,
				note: draft.note,
				source: draft.source,
				status: item.status,
				savedAt: item.savedAt
			});
		} catch {
			setEditError("That doesn’t look like a web link.");
			return;
		}
		if (findDuplicate(items, next.url, item.id)) {
			setEditError("You already have this link.");
			return;
		}
		setItems((current) => current.map((existing) => existing.id === item.id ? next : existing));
		setEditingId(null);
		setEditError(null);
	}
	function remove(item) {
		setItems((current) => current.filter((existing) => existing.id !== item.id));
		setUndo(item);
		setConfirmDeleteId(null);
		if (editingId === item.id) setEditingId(null);
		if (highlightId === item.id) setHighlightId(null);
	}
	function restore() {
		if (!undo) return;
		setItems((current) => {
			if (findDuplicate(current, undo.url)) return current;
			return [undo, ...current];
		});
		setUndo(null);
	}
	async function copyUrl(value, id) {
		try {
			await navigator.clipboard.writeText(value);
			setCopiedId(id);
			window.setTimeout(() => setCopiedId((current) => current === id ? null : current), 1600);
		} catch {
			setFormError("Couldn’t copy that link.");
		}
	}
	function download(filename, content, type) {
		const blob = new Blob([content], { type });
		const objectUrl = URL.createObjectURL(blob);
		const anchor = document.createElement("a");
		anchor.href = objectUrl;
		anchor.download = filename;
		anchor.click();
		URL.revokeObjectURL(objectUrl);
	}
	function stamp() {
		const now = /* @__PURE__ */ new Date();
		const month = String(now.getMonth() + 1).padStart(2, "0");
		const day = String(now.getDate()).padStart(2, "0");
		return `${now.getFullYear()}-${month}-${day}`;
	}
	async function onFile(file) {
		const text = await file.text();
		if (fileRef.current) fileRef.current.value = "";
		let incoming;
		try {
			incoming = parseImport(text);
		} catch (error) {
			setPending(null);
			setImportMessage(error instanceof Error ? error.message : "Couldn’t read that file.");
			return;
		}
		if (incoming.length === 0) {
			setPending(null);
			setImportMessage("No links found in that file.");
			return;
		}
		if (storageError && !replaceAll) {
			setPending(null);
			setImportMessage("Saved links couldn’t be read. Turn on “Replace the whole list” to import anyway.");
			return;
		}
		if (replaceAll) {
			setPending(incoming);
			setImportMessage(null);
			return;
		}
		const result = mergeItems(items, incoming);
		setItems(result.items);
		setPersist(true);
		setStorageError(null);
		setPending(null);
		setImportMessage(`Added ${result.added}. Skipped ${result.skipped} already saved.`);
	}
	function confirmReplace() {
		if (!pending) return;
		setItems(pending);
		setPersist(true);
		setStorageError(null);
		setImportMessage(`Replaced the list with ${pending.length} ${pending.length === 1 ? "link" : "links"}.`);
		setPending(null);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "shell flex flex-col gap-5",
		"data-ready": ready ? "true" : "false",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "wordmark",
						children: "Later"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: "Save a link. Decide later."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex shrink-0 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-secondary",
						"aria-expanded": dataOpen,
						"aria-controls": "data-panel",
						onClick: () => setDataOpen((open) => !open),
						children: "Data"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-secondary",
						"aria-label": theme === "dark" ? "Switch to light theme" : "Switch to dark theme",
						onClick: toggleTheme,
						children: theme === "dark" ? "Light" : "Dark"
					})]
				})]
			}),
			dataOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "data-panel",
				className: "panel flex flex-col gap-3",
				"aria-label": "Backup and install",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Everything stays in this browser. Export a file if you want a backup. Clearing site data deletes the list."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "btn btn-secondary",
							onClick: () => download(`later-${stamp()}.json`, exportJson(items), "application/json"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
								className: "size-4",
								"aria-hidden": true
							}), " JSON"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "btn btn-secondary",
							onClick: () => download(`later-${stamp()}.csv`, exportCsv(items), "text/csv"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
								className: "size-4",
								"aria-hidden": true
							}), " CSV"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex min-h-11 items-center gap-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: replaceAll,
							onChange: (event) => {
								setReplaceAll(event.target.checked);
								setPending(null);
							}
						}), "Replace the whole list"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "btn btn-secondary btn-block",
						onClick: () => fileRef.current?.click(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, {
							className: "size-4",
							"aria-hidden": true
						}), " Import JSON or CSV"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: fileRef,
						className: "sr-only",
						type: "file",
						accept: ".json,.csv,application/json,text/csv",
						onChange: (event) => {
							const file = event.target.files?.[0];
							if (file) onFile(file);
						}
					}),
					pending ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2",
						role: "alert",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm",
							children: [
								"Replace ",
								items.length,
								" saved ",
								items.length === 1 ? "link" : "links",
								" with ",
								pending.length,
								" from the file?"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-danger",
								onClick: confirmReplace,
								children: "Replace"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-secondary",
								onClick: () => setPending(null),
								children: "Cancel"
							})]
						})]
					}) : null,
					importMessage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						role: "status",
						children: importMessage
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 text-sm text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium text-foreground",
								children: "Add to your home screen"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Android: open the published app in Chrome, then the browser menu, then Install app or Add to Home screen." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "iPhone: open it in Safari, tap Share, then Add to Home Screen." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "After it has loaded once, the list still opens with no connection. Nothing is sent to a server." })
						]
					})
				]
			}) : null,
			storageError ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "panel flex flex-col gap-3",
				role: "alert",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm",
					children: [storageError, " New saves are paused so the old data is not overwritten."]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-secondary",
					onClick: () => {
						setItems([]);
						setPersist(true);
						setStorageError(null);
					},
					children: "Start fresh"
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "panel flex flex-col gap-3",
				onSubmit,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-sm font-medium",
							htmlFor: "link-url",
							children: "Link"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "link-url",
								className: "field min-w-0",
								inputMode: "url",
								autoCapitalize: "off",
								autoCorrect: "off",
								spellCheck: false,
								autoComplete: "off",
								placeholder: "https://",
								"aria-invalid": formError ? true : void 0,
								value: url,
								onChange: (event) => applyUrl(event.target.value),
								onPaste: (event) => {
									const text = event.clipboardData.getData("text");
									const next = extractUrl(text);
									if (next && next !== text.trim()) {
										event.preventDefault();
										applyUrl(next, true);
									}
								}
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "btn btn-secondary shrink-0",
								onClick: () => void pasteFromClipboard(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardPaste, {
									className: "size-4",
									"aria-hidden": true
								}), " Paste"]
							})]
						})]
					}),
					previewDomain ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-subtle-foreground",
						children: previewDomain
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1.5 text-sm font-medium",
						htmlFor: "link-name",
						children: ["Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "link-name",
							className: "field",
							autoComplete: "off",
							placeholder: "Suggested from the link",
							value: name,
							onChange: (event) => {
								setName(event.target.value);
								setNameDirty(event.target.value.trim().length > 0);
								setJustSaved(null);
							}
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
						className: "btn btn-secondary btn-block",
						children: "Note and source"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-col gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1.5 text-sm font-medium",
							htmlFor: "link-note",
							children: [
								"Note ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-normal text-muted-foreground",
									children: "optional"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									id: "link-note",
									className: "field",
									placeholder: "Why it looked worth opening",
									value: note,
									onChange: (event) => {
										setNote(event.target.value);
										setJustSaved(null);
									}
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "grid gap-1.5 text-sm font-medium",
							htmlFor: "link-source",
							children: [
								"Source ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-normal text-muted-foreground",
									children: "optional"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "link-source",
									className: "field",
									autoComplete: "off",
									spellCheck: false,
									placeholder: "r/androidapps or a post title",
									value: source,
									onChange: (event) => setSource(event.target.value)
								})
							]
						})]
					})] }),
					liveDuplicate ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-sm border border-border bg-elevated px-3 py-3 text-sm",
						role: "status",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							"Already saved as ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium text-foreground",
								children: liveDuplicate.name
							}),
							` · ${formatWhen(liveDuplicate.savedAt)}`,
							"."
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-secondary mt-2",
							onClick: () => reveal(liveDuplicate.id),
							children: "Show saved link"
						})]
					}) : null,
					formError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-skip",
						role: "alert",
						children: formError
					}) : null,
					justSaved && !liveDuplicate ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-keep",
						role: "status",
						children: ["Saved ", justSaved]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: liveDuplicate ? "button" : "submit",
						className: "btn btn-primary btn-block",
						disabled: !persist || !url.trim(),
						onClick: liveDuplicate ? saveLink : void 0,
						children: liveDuplicate ? "Save another copy" : "Save link"
					})
				]
			}),
			!ready ? null : items.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3",
				"aria-label": "Saved links",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium text-foreground tabular-nums",
								children: stats.saved
							}),
							" saved",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								"aria-hidden": true,
								children: " · "
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium text-foreground tabular-nums",
								children: stats.checked
							}),
							" checked",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								"aria-hidden": true,
								children: " · "
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium text-keep tabular-nums",
								children: stats.kept
							}),
							" kept",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								"aria-hidden": true,
								children: " · "
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-medium text-skip tabular-nums",
								children: stats.skipped
							}),
							" skipped"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
								className: "size-4 shrink-0 text-muted-foreground",
								"aria-hidden": true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "sr-only",
								htmlFor: "link-search",
								children: "Search saved links"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "link-search",
								className: "field",
								type: "search",
								placeholder: "Search name, note, subreddit",
								value: query,
								onChange: (event) => setQuery(event.target.value)
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						role: "group",
						"aria-label": "Filter by status",
						children: STATUS_FILTERS.map((filter) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-secondary",
							"aria-pressed": statusFilter === filter.id,
							onClick: () => setStatusFilter(filter.id),
							children: filter.label
						}, filter.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "sr-only",
								htmlFor: "link-when",
								children: "Filter by date saved"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								id: "link-when",
								className: "field",
								value: dateFilter,
								onChange: (event) => setDateFilter(event.target.value),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "all",
										children: "Any date"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "today",
										children: "Today"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "7d",
										children: "Last 7 days"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "30d",
										children: "Last 30 days"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "sr-only",
								htmlFor: "link-sort",
								children: "Sort by date saved"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								id: "link-sort",
								className: "field",
								value: sort,
								onChange: (event) => setSort(event.target.value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "newest",
									children: "Newest"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "oldest",
									children: "Oldest"
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "btn btn-secondary btn-block",
						onClick: pickRandom,
						disabled: stats.open === 0,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shuffle, {
							className: "size-4",
							"aria-hidden": true
						}), stats.open === 0 ? "Nothing left to check" : "Pick one to check"]
					}),
					undo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "panel flex items-center justify-between gap-3",
						role: "status",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "min-w-0 truncate text-sm",
							children: ["Removed ", undo.name]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-secondary shrink-0",
							onClick: restore,
							children: "Undo"
						})]
					}) : null,
					visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "panel flex flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "Nothing matches."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "btn btn-secondary",
							onClick: () => {
								setQuery("");
								setStatusFilter("all");
								setDateFilter("all");
							},
							children: "Clear filters"
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-3",
						children: visible.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkCard, {
							item,
							featured: item.id === highlightId,
							editing: editingId === item.id,
							draft,
							editError,
							confirmDelete: confirmDeleteId === item.id,
							copied: copiedId === item.id,
							onDraft: setDraft,
							onStatus: (status) => setStatus(item.id, status),
							onEdit: () => startEdit(item),
							onCancelEdit: () => {
								setEditingId(null);
								setEditError(null);
							},
							onSaveEdit: () => saveEdit(item),
							onAskDelete: () => {
								setConfirmDeleteId(item.id);
								setEditingId(null);
							},
							onCancelDelete: () => setConfirmDeleteId(null),
							onDelete: () => remove(item),
							onCopy: () => void copyUrl(item.url, item.id)
						}) }, item.id))
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "panel",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-medium",
					children: "Nothing saved yet"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Paste a link from Reddit. It stays on this device until you export it."
				})]
			})
		]
	});
}
function paintThemeColor(theme) {
	const meta = document.querySelector("meta[name=\"theme-color\"]");
	if (meta) meta.setAttribute("content", theme === "dark" ? "#0e0e10" : "#f4f3ef");
}
function LinkCard({ item, featured, editing, draft, editError, confirmDelete, copied, onDraft, onStatus, onEdit, onCancelEdit, onSaveEdit, onAskDelete, onCancelDelete, onDelete, onCopy }) {
	const tone = item.status === "keeper" ? "tone-keeper" : item.status === "skip" ? "tone-skip" : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
		id: `link-${item.id}`,
		className: featured ? "panel is-featured flex flex-col gap-3" : "panel flex flex-col gap-3",
		children: editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "flex flex-col gap-3",
			onSubmit: (event) => {
				event.preventDefault();
				onSaveEdit();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "grid gap-1.5 text-sm font-medium",
					htmlFor: "edit-name",
					children: ["Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "edit-name",
						className: "field",
						value: draft.name,
						onChange: (event) => onDraft({
							...draft,
							name: event.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "grid gap-1.5 text-sm font-medium",
					htmlFor: "edit-url",
					children: ["Link", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "edit-url",
						className: "field",
						inputMode: "url",
						autoCapitalize: "off",
						autoCorrect: "off",
						spellCheck: false,
						value: draft.url,
						onChange: (event) => onDraft({
							...draft,
							url: event.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "grid gap-1.5 text-sm font-medium",
					htmlFor: "edit-note",
					children: ["Note", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						id: "edit-note",
						className: "field",
						value: draft.note,
						onChange: (event) => onDraft({
							...draft,
							note: event.target.value
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "grid gap-1.5 text-sm font-medium",
					htmlFor: "edit-source",
					children: ["Source", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "edit-source",
						className: "field",
						value: draft.source,
						onChange: (event) => onDraft({
							...draft,
							source: event.target.value
						})
					})]
				}),
				editError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-skip",
					role: "alert",
					children: editError
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "btn btn-primary",
						children: "Save changes"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-secondary",
						onClick: onCancelEdit,
						children: "Cancel"
					})]
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-baseline justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "min-w-0 text-base font-semibold leading-snug",
					children: item.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "max-w-32 shrink-0 truncate text-sm text-muted-foreground",
					children: item.domain
				})]
			}),
			item.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm break-words text-muted-foreground",
				children: item.note
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: `text-sm ${tone || "text-muted-foreground"}`,
				children: [
					statusLabel(item.status),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": true,
						children: " · "
					}),
					item.source ? `${item.source} · ` : "",
					formatWhen(item.savedAt)
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "line-clamp-2 text-sm break-all text-subtle-foreground",
				children: item.url
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-3 gap-2",
				role: "group",
				"aria-label": `Status for ${item.name}`,
				children: STATUS_META.map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-secondary status-btn px-2 text-center",
					"data-status": status.id,
					"aria-pressed": item.status === status.id,
					"aria-label": `Set ${item.name} to ${status.long}`,
					onClick: () => onStatus(status.id),
					children: status.short
				}, status.id))
			}),
			confirmDelete ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				role: "group",
				"aria-label": "Confirm delete",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-danger",
					onClick: onDelete,
					children: "Delete"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-secondary",
					onClick: onCancelDelete,
					children: "Cancel"
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						className: "btn btn-secondary",
						href: item.url,
						target: "_blank",
						rel: "noopener noreferrer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, {
							className: "size-4",
							"aria-hidden": true
						}), " Open"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "btn btn-secondary",
						onClick: onCopy,
						children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
							className: "size-4",
							"aria-hidden": true
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
							className: "size-4",
							"aria-hidden": true
						}), copied ? "Copied" : "Copy"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "btn btn-secondary",
						onClick: onEdit,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {
							className: "size-4",
							"aria-hidden": true
						}), " Edit"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "btn btn-danger",
						onClick: onAskDelete,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
							className: "size-4",
							"aria-hidden": true
						}), " Delete"]
					})
				]
			})
		] })
	});
}
function statusLabel(id) {
	return STATUS_META.find((status) => status.id === id)?.long ?? "To check";
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LaterApp, {});
}
//#endregion
export { Home as component };
