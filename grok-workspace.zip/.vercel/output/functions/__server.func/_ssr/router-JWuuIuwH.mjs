import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, _ as createFileRoute, b as require_jsx_runtime, d as Scripts, f as HeadContent, g as lazyRouteComponent, h as Outlet, m as createRouter, v as createRootRoute, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-JWuuIuwH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
/**
* Later — a link queue that never leaves this browser.
*
* Storage key: localStorage["later.links.v1"]
* Shape: { v: 1, items: Item[] }
*
* Status ids stay stable so old saves still match. Change the labels here:
*   to-check  "To check"
*   keeper    "Checked – keeper"
*   skip      "Checked – skip"
*
* Two URLs count as the same when the host (ignoring www), path, query, and
* hash match after http/https is folded together, a trailing slash is dropped,
* and common tracking params (utm_*, fbclid, gclid, …) are removed.
* The path keeps its original casing. Nothing is fetched from the URL.
*/
var STORAGE_KEY = "later.links.v1";
var THEME_KEY = "later.theme";
var STATUS_META = [
	{
		id: "to-check",
		short: "To check",
		long: "To check"
	},
	{
		id: "keeper",
		short: "Keeper",
		long: "Checked – keeper"
	},
	{
		id: "skip",
		short: "Skip",
		long: "Checked – skip"
	}
];
var TRACKING = /* @__PURE__ */ new Set([
	"utm_source",
	"utm_medium",
	"utm_campaign",
	"utm_term",
	"utm_content",
	"utm_id",
	"utm_name",
	"fbclid",
	"gclid",
	"gbraid",
	"wbraid",
	"igshid",
	"mc_cid",
	"mc_eid",
	"ref",
	"ref_src",
	"si"
]);
var PUBLIC_SUFFIX_2 = /* @__PURE__ */ new Set([
	"co.uk",
	"org.uk",
	"ac.uk",
	"com.au",
	"net.au",
	"co.nz",
	"co.jp",
	"com.br",
	"com.mx",
	"co.za",
	"com.tr"
]);
var HOSTERS = /* @__PURE__ */ new Set([
	"github.io",
	"vercel.app",
	"netlify.app",
	"pages.dev",
	"web.app",
	"firebaseapp.com",
	"herokuapp.com",
	"glitch.me",
	"notion.site",
	"framer.app",
	"fly.dev"
]);
function statusMeta(id) {
	return STATUS_META.find((status) => status.id === id) ?? STATUS_META[0];
}
/** Pull a URL out of a Reddit share, a markdown link, or a bare paste. */
function extractUrl(text) {
	const markdown = text.match(/\((https?:\/\/[^)\s]+)\)/i);
	if (markdown?.[1]) return trimUrlJunk(markdown[1]);
	const absolute = text.match(/https?:\/\/[^\s<>"']+/i);
	if (absolute?.[0]) return trimUrlJunk(absolute[0]);
	return text.trim();
}
function trimUrlJunk(value) {
	return value.replace(/[),.;]+$/, "");
}
/**
* Canonical URL we store and compare.
* Returns null when the text is not an http(s) link.
*/
function normalizeUrl(raw) {
	const extracted = extractUrl(raw);
	if (!extracted) return null;
	let candidate = extracted;
	if (!/^[a-z][a-z0-9+.-]*:/i.test(candidate)) candidate = `https://${candidate}`;
	let url;
	try {
		url = new URL(candidate);
	} catch {
		return null;
	}
	if (url.protocol !== "http:" && url.protocol !== "https:") return null;
	if (url.protocol === "http:" && (url.port === "" || url.port === "80")) {
		url.protocol = "https:";
		url.port = "";
	}
	url.hostname = url.hostname.toLowerCase().replace(/^www\./, "");
	if (url.protocol === "https:" && url.port === "443") url.port = "";
	const kept = [...url.searchParams.entries()].filter(([key]) => !TRACKING.has(key.toLowerCase())).sort((a, b) => a[0].localeCompare(b[0]) || a[1].localeCompare(b[1]));
	url.search = "";
	for (const [key, value] of kept) url.searchParams.append(key, value);
	if (url.pathname.length > 1 && url.pathname.endsWith("/")) url.pathname = url.pathname.slice(0, -1);
	return url.toString();
}
function domainOf(normalized) {
	try {
		return new URL(normalized).hostname;
	} catch {
		return "";
	}
}
function suggestName(raw) {
	const normalized = normalizeUrl(raw);
	if (!normalized) return "";
	const url = new URL(normalized);
	const host = url.hostname;
	if (host === "youtu.be" || host.endsWith("youtube.com")) return "YouTube";
	if (host === "apps.apple.com" || host.endsWith(".apple.com")) {
		const parts = url.pathname.split("/").filter(Boolean);
		const appAt = parts.indexOf("app");
		if (appAt >= 0 && parts[appAt + 1] && !parts[appAt + 1].startsWith("id")) return titleCase(parts[appAt + 1]);
	}
	if (host === "play.google.com") {
		const id = url.searchParams.get("id");
		if (id) return titleCase(id.split(".").pop() ?? id);
	}
	if (host === "github.com" || host.endsWith(".github.com")) {
		const parts = url.pathname.split("/").filter(Boolean);
		if (parts[1]) return titleCase(parts[1]);
		if (parts[0]) return titleCase(parts[0]);
	}
	if (host.endsWith("reddit.com")) {
		const parts = url.pathname.split("/").filter(Boolean);
		if (parts[0] === "r" && parts[1]) return `r/${parts[1]}`;
	}
	return titleCase(siteLabel(host));
}
function siteLabel(hostname) {
	const parts = hostname.split(".").filter(Boolean);
	if (parts.length <= 1) return parts[0] ?? hostname;
	const last2 = parts.slice(-2).join(".");
	const last3 = parts.slice(-3).join(".");
	if (HOSTERS.has(last2) && parts.length >= 3) return parts[parts.length - 3];
	if (HOSTERS.has(last3) && parts.length >= 4) return parts[parts.length - 4];
	if (PUBLIC_SUFFIX_2.has(last2) && parts.length >= 3) return parts[parts.length - 3];
	return parts[parts.length - 2];
}
function titleCase(value) {
	let cleaned = value;
	try {
		cleaned = decodeURIComponent(value);
	} catch {
		cleaned = value;
	}
	cleaned = cleaned.replace(/[-_]+/g, " ").replace(/\s+/g, " ").trim();
	if (!cleaned) return "";
	return cleaned.replace(/(^|\s)([a-z])/g, (_match, space, char) => space + char.toUpperCase());
}
function findDuplicate(items, rawUrl, exceptId) {
	const key = normalizeUrl(rawUrl);
	if (!key) return void 0;
	return items.find((item) => item.id !== exceptId && normalizeUrl(item.url) === key);
}
function counts(items) {
	let kept = 0;
	let skipped = 0;
	for (const item of items) if (item.status === "keeper") kept += 1;
	else if (item.status === "skip") skipped += 1;
	return {
		saved: items.length,
		checked: kept + skipped,
		kept,
		skipped,
		open: items.length - kept - skipped
	};
}
function matchesDate(iso, filter, now = /* @__PURE__ */ new Date()) {
	if (filter === "all") return true;
	const time = new Date(iso).getTime();
	if (Number.isNaN(time)) return false;
	if (filter === "today") {
		const start = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
		return time >= start && time < start + 864e5;
	}
	const days = filter === "7d" ? 7 : 30;
	return time >= now.getTime() - days * 864e5;
}
function matchesQuery(item, query) {
	const needle = query.trim().toLowerCase();
	if (!needle) return true;
	return [
		item.name,
		item.url,
		item.domain,
		item.note,
		item.source,
		statusMeta(item.status).long,
		statusMeta(item.status).short
	].join("\n").toLowerCase().includes(needle);
}
function matchesStatus(item, filter) {
	if (filter === "all") return true;
	if (filter === "checked") return item.status === "keeper" || item.status === "skip";
	return item.status === filter;
}
function formatWhen(iso, now = /* @__PURE__ */ new Date()) {
	const date = new Date(iso);
	if (Number.isNaN(date.getTime())) return "";
	const startToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
	const startThat = new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
	const diff = Math.round((startToday - startThat) / 864e5);
	if (diff === 0) return "Today";
	if (diff === 1) return "Yesterday";
	return date.toLocaleDateString(void 0, {
		month: "short",
		day: "numeric",
		year: date.getFullYear() === now.getFullYear() ? void 0 : "numeric"
	});
}
function createItem(input) {
	const url = normalizeUrl(input.url);
	if (!url) throw new Error("Not a web link");
	const name = input.name.trim() || suggestName(url) || domainOf(url);
	return {
		id: input.id?.trim() || newId(),
		name,
		url,
		domain: domainOf(url),
		note: (input.note ?? "").trim(),
		source: (input.source ?? "").trim(),
		status: input.status ?? "to-check",
		savedAt: input.savedAt && !Number.isNaN(new Date(input.savedAt).getTime()) ? new Date(input.savedAt).toISOString() : (/* @__PURE__ */ new Date()).toISOString()
	};
}
function exportJson(items) {
	return JSON.stringify({
		v: 1,
		items
	}, null, 2);
}
var CSV_COLUMNS = [
	"name",
	"url",
	"domain",
	"note",
	"source",
	"status",
	"savedAt"
];
function exportCsv(items) {
	const lines = [CSV_COLUMNS.join(",")];
	for (const item of items) lines.push(CSV_COLUMNS.map((column) => csvEscape(item[column])).join(","));
	return lines.join("\n");
}
function csvEscape(value) {
	if (/[",\n\r]/.test(value)) return `"${value.replace(/"/g, "\"\"")}"`;
	return value;
}
function parseCsvRows(text) {
	const source = text.replace(/^\uFEFF/, "");
	const rows = [];
	let row = [];
	let cell = "";
	let quoted = false;
	for (let i = 0; i < source.length; i += 1) {
		const char = source[i];
		if (quoted) {
			if (char === "\"") {
				if (source[i + 1] === "\"") {
					cell += "\"";
					i += 1;
				} else quoted = false;
			} else cell += char;
			continue;
		}
		if (char === "\"") {
			quoted = true;
			continue;
		}
		if (char === ",") {
			row.push(cell);
			cell = "";
			continue;
		}
		if (char === "\n") {
			row.push(cell);
			rows.push(row);
			row = [];
			cell = "";
			continue;
		}
		if (char === "\r") continue;
		cell += char;
	}
	if (cell.length > 0 || row.length > 0) {
		row.push(cell);
		rows.push(row);
	}
	return rows;
}
function parseStored(raw) {
	let data;
	try {
		data = JSON.parse(raw);
	} catch {
		throw new Error("Saved links could not be read.");
	}
	const list = Array.isArray(data) ? data : isRecord(data) ? data.items : null;
	if (!Array.isArray(list)) throw new Error("Saved links could not be read.");
	const items = list.map(coerceItem).filter((item) => item !== null);
	if (list.length > 0 && items.length === 0) throw new Error("Saved links could not be read.");
	return sortNewest(dedupeIds(items));
}
/** Import either the JSON export or a CSV with a url column. */
function parseImport(text) {
	const trimmed = text.replace(/^\uFEFF/, "").trim();
	if (!trimmed) return [];
	if (trimmed.startsWith("{") || trimmed.startsWith("[")) return parseStored(trimmed);
	return parseCsv(trimmed);
}
function parseCsv(text) {
	const rows = parseCsvRows(text).filter((row) => row.some((cell) => cell.trim()));
	if (rows.length === 0) return [];
	const header = rows[0].map((cell) => cell.trim().toLowerCase().replace(/[\s_-]/g, ""));
	const urlIndex = header.indexOf("url");
	if (urlIndex === -1) throw new Error("CSV needs a url column.");
	const indexOf = (name) => header.indexOf(name);
	const savedIndex = indexOf("savedat") === -1 ? indexOf("date") : indexOf("savedat");
	const items = [];
	for (const row of rows.slice(1)) {
		const rawUrl = row[urlIndex] ?? "";
		if (!normalizeUrl(rawUrl)) continue;
		const pick = (name) => {
			const index = indexOf(name);
			return index === -1 ? "" : row[index] ?? "";
		};
		const item = coerceItem({
			id: pick("id"),
			name: pick("name"),
			url: rawUrl,
			note: pick("note"),
			source: pick("source"),
			status: pick("status"),
			savedAt: savedIndex === -1 ? "" : row[savedIndex] ?? ""
		});
		if (item) items.push(item);
	}
	return sortNewest(dedupeIds(items));
}
function mergeItems(current, incoming) {
	const seen = new Set(current.map((item) => normalizeUrl(item.url)).filter((url) => Boolean(url)));
	const next = [...current];
	let added = 0;
	let skipped = 0;
	for (const item of incoming) {
		const key = normalizeUrl(item.url);
		if (!key || seen.has(key)) {
			skipped += 1;
			continue;
		}
		seen.add(key);
		next.push({
			...item,
			url: key,
			domain: domainOf(key)
		});
		added += 1;
	}
	return {
		items: sortNewest(dedupeIds(next)),
		added,
		skipped
	};
}
function coerceItem(value) {
	const record = isRecord(value) ? value : null;
	if (!record) return null;
	const url = normalizeUrl(typeof record.url === "string" ? record.url : "");
	if (!url) return null;
	const nameValue = typeof record.name === "string" ? record.name.trim() : "";
	const savedRaw = typeof record.savedAt === "string" ? record.savedAt : "";
	const savedAt = savedRaw && !Number.isNaN(new Date(savedRaw).getTime()) ? new Date(savedRaw).toISOString() : (/* @__PURE__ */ new Date()).toISOString();
	return {
		id: typeof record.id === "string" && record.id.trim() ? record.id.trim() : newId(),
		name: nameValue || suggestName(url) || domainOf(url),
		url,
		domain: domainOf(url),
		note: typeof record.note === "string" ? record.note.trim() : "",
		source: typeof record.source === "string" ? record.source.trim() : "",
		status: coerceStatus(record.status),
		savedAt
	};
}
function coerceStatus(value) {
	const text = String(value ?? "").toLowerCase().replace(/[–—]/g, "-").replace(/\s+/g, " ").trim();
	if ([
		"keeper",
		"kept",
		"keep",
		"checked - keeper",
		"checked-keeper"
	].includes(text)) return "keeper";
	if ([
		"skip",
		"skipped",
		"checked - skip",
		"checked-skip"
	].includes(text)) return "skip";
	return "to-check";
}
function dedupeIds(items) {
	const seen = /* @__PURE__ */ new Set();
	return items.map((item) => {
		if (!seen.has(item.id)) {
			seen.add(item.id);
			return item;
		}
		const id = newId();
		seen.add(id);
		return {
			...item,
			id
		};
	});
}
function sortNewest(items) {
	return [...items].sort((a, b) => b.savedAt.localeCompare(a.savedAt) || a.name.localeCompare(b.name));
}
function isRecord(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function newId() {
	if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return crypto.randomUUID();
	return `id-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}
var styles_default = "/assets/styles-W4EbiRh2.css";
var APP_NAME = "Later";
var themeBoot = `(function(){try{if(localStorage.getItem(${JSON.stringify(THEME_KEY)})==="light")document.documentElement.classList.remove("dark");}catch(e){}})();`;
var Route$1 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1, viewport-fit=cover"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "Save apps and sites you find on Reddit, then decide later what is worth opening. Stored on this device."
			},
			{
				name: "theme-color",
				content: "#0e0e10"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "dark",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("head", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", { dangerouslySetInnerHTML: { __html: themeBoot } })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter = () => import("./routes-n6H6kIyr.mjs");
var rootRouteChildren = { IndexRoute: createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter, "component") }).update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$1
}) };
var routeTree = Route$1._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { normalizeUrl as _, counts as a, suggestName as b, exportCsv as c, findDuplicate as d, formatWhen as f, mergeItems as g, matchesStatus as h, THEME_KEY as i, exportJson as l, matchesQuery as m, STATUS_META as n, createItem as o, matchesDate as p, STORAGE_KEY as r, domainOf as s, router_exports as t, extractUrl as u, parseImport as v, parseStored as y };
